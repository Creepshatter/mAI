import json
import time
try:
    with open("brain.json", "r") as f:
        brain = json.load(f)
except:
    brain = {}

print("AI: Sys Online. 'quit' to stop.")

while True:
    user_input = input("You: ").lower().strip().replace("?", "")

    if user_input.lower() == "quit":
        print("AI: Bye!!")
        break

    if user_input in brain:
        print("AI is thinking...")
        time.sleep(0.8)
        print("AI: ", brain[user_input])

    else:
        user_answer = input("I'm a new AI can you tell the answer so i can learn for later: ")
        brain[user_input] = user_answer
        print("Now My Memory Conatains:")
        print(brain)
        with open("brain.json", "w") as f:
            json.dump(brain, f)
